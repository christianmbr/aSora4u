﻿// Programador: Christian Mateo Benitez.
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmIndiceMasaCorporal : Form
    {
        public frmIndiceMasaCorporal()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            var Peso = 0.0;
            // Variable para guardar el peso.
            var Altura = 0.0;
            // Variable para guardar la Altura.
            int IMC = 0;
            // Variable para guardar el Indice De Masa Corporal.

            try
            {
                if (!(txtAltura.Text == "" || txtPeso.Text == ""))
                // Condicional que verifica si el usuario ingreso los datos completos.
                {
                    Peso = double.Parse(txtPeso.Text);
                    // Variable donde se asigna el valor del peso ingresado por el usuario.
                    Altura = double.Parse(txtAltura.Text);
                    // Variable donde se asigna el valor del peso ingresado por el usuario.
                    IMC = Convert.ToInt32(Peso / Math.Pow(Altura, 2));
                    // Calcula el indice de masa corporal en la variable IMC.

                    lblResultadoIMC.Text = Convert.ToString(IMC);
                    // Se imprime en el lavel resultado la variable IMC.

                }
                else
                {
                    MessageBox.Show("Asegurate en no dejar espacios sin llenar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Imprime información al usuario por si deja algun campo sin llenar.
                }
            }
            catch(FormatException ex)
            {
                MessageBox.Show("Asegura que los datos ingresados sean correctos.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Imprime información al usuario por si ingresa datos incorrectos.
            }

            if (IMC < 18.5)
                mostrarinfo("INSUFICIENCIA PONDERAL", 1);
            if (IMC >= 18.5 && IMC <= 24.9)
                mostrarinfo("PESO NORMAL", 2);
            if (IMC >= 25.0 && IMC <= 29.9)
                mostrarinfo("SOBREPESO", 3);
            if (IMC >= 30.0 && IMC <= 34.9)
                mostrarinfo("OBESIDAD CLASE", 4);
            if (IMC >= 35.0 && IMC <= 39.9)
                mostrarinfo("OBESIDAD CLASE II", 4);
            if (IMC >= 40.0)
                mostrarinfo("OBESIDAD CLASE III", 4);
            // Bloque de ifs para determinar la respectiva clase según su IMC.
        }
        private void mostrarinfo(string informacion, int color)
        {
            switch (color)
            {
                case 1:
                    lblClasificacionImc.ForeColor = Color.Yellow;
                    break;
                case 2:
                    lblClasificacionImc.ForeColor = Color.Green;
                    break;
                case 3:
                    lblClasificacionImc.ForeColor = Color.Orange;
                    break;
                case 4:
                    lblClasificacionImc.ForeColor = Color.Red;
                    break;
            }
            // Swith que determina el color del label cuando se muestre.

            lblClasificacionImc.Text = informacion;
            // Se muestra en el formulario la clasificación del IMC.

            lblResultadoIMC.Visible = true;
            lblIMC.Visible = true;
            lblIgual.Visible = true;
            lblClasificacionImc.Visible = true;
            // Se visualizan los labels invisibles.
        }
        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            char caracter = e.KeyChar;

            if (Char.IsNumber(caracter) || (caracter == (char)(Keys.Back)) || (caracter == ','))
                e.Handled = false;
            else
                e.Handled = true;
        }
        private void txtPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            char caracter = e.KeyChar;

            if (Char.IsNumber(caracter) || (caracter == (char)(Keys.Back)) || (caracter == ','))
                e.Handled = false;
            else
                e.Handled = true;
        }
    }
}
