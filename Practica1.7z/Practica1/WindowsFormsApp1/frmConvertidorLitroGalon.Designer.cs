﻿namespace WindowsFormsApp1
{
    partial class frmConvertidorLitroGalon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbLitros = new System.Windows.Forms.TextBox();
            this.lblLitros = new System.Windows.Forms.Label();
            this.lblIgual = new System.Windows.Forms.Label();
            this.lblGalon = new System.Windows.Forms.Label();
            this.lblVolumen = new System.Windows.Forms.Label();
            this.txtGalon = new System.Windows.Forms.TextBox();
            this.lblInstruccion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtbLitros
            // 
            this.txtbLitros.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbLitros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtbLitros.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbLitros.Location = new System.Drawing.Point(11, 31);
            this.txtbLitros.Name = "txtbLitros";
            this.txtbLitros.Size = new System.Drawing.Size(177, 32);
            this.txtbLitros.TabIndex = 0;
            this.txtbLitros.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbLitros.TextChanged += new System.EventHandler(this.txtbLitros_TextChanged);
            // 
            // lblLitros
            // 
            this.lblLitros.AutoEllipsis = true;
            this.lblLitros.AutoSize = true;
            this.lblLitros.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLitros.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblLitros.Location = new System.Drawing.Point(11, 61);
            this.lblLitros.Name = "lblLitros";
            this.lblLitros.Size = new System.Drawing.Size(177, 15);
            this.lblLitros.TabIndex = 1;
            this.lblLitros.Text = "                                           LITROS";
            this.lblLitros.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblIgual
            // 
            this.lblIgual.AutoSize = true;
            this.lblIgual.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIgual.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblIgual.Location = new System.Drawing.Point(196, 37);
            this.lblIgual.Name = "lblIgual";
            this.lblIgual.Size = new System.Drawing.Size(25, 25);
            this.lblIgual.TabIndex = 2;
            this.lblIgual.Text = "=";
            // 
            // lblGalon
            // 
            this.lblGalon.AutoEllipsis = true;
            this.lblGalon.AutoSize = true;
            this.lblGalon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGalon.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblGalon.Location = new System.Drawing.Point(227, 61);
            this.lblGalon.Name = "lblGalon";
            this.lblGalon.Size = new System.Drawing.Size(177, 15);
            this.lblGalon.TabIndex = 1;
            this.lblGalon.Text = "                                       GALONES";
            this.lblGalon.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblVolumen
            // 
            this.lblVolumen.AutoSize = true;
            this.lblVolumen.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVolumen.Location = new System.Drawing.Point(12, 9);
            this.lblVolumen.Name = "lblVolumen";
            this.lblVolumen.Size = new System.Drawing.Size(48, 15);
            this.lblVolumen.TabIndex = 3;
            this.lblVolumen.Text = "Volumen";
            // 
            // txtGalon
            // 
            this.txtGalon.AcceptsReturn = true;
            this.txtGalon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGalon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtGalon.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGalon.Location = new System.Drawing.Point(227, 31);
            this.txtGalon.Name = "txtGalon";
            this.txtGalon.ReadOnly = true;
            this.txtGalon.Size = new System.Drawing.Size(177, 32);
            this.txtGalon.TabIndex = 0;
            this.txtGalon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblInstruccion
            // 
            this.lblInstruccion.AutoSize = true;
            this.lblInstruccion.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruccion.Location = new System.Drawing.Point(48, 76);
            this.lblInstruccion.Name = "lblInstruccion";
            this.lblInstruccion.Size = new System.Drawing.Size(140, 23);
            this.lblInstruccion.TabIndex = 4;
            this.lblInstruccion.Text = "INGRESA LITROS";
            // 
            // frmConvertidorLitroGalon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 121);
            this.Controls.Add(this.lblInstruccion);
            this.Controls.Add(this.lblVolumen);
            this.Controls.Add(this.lblIgual);
            this.Controls.Add(this.lblGalon);
            this.Controls.Add(this.lblLitros);
            this.Controls.Add(this.txtGalon);
            this.Controls.Add(this.txtbLitros);
            this.Name = "frmConvertidorLitroGalon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Convertidor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbLitros;
        private System.Windows.Forms.Label lblLitros;
        private System.Windows.Forms.Label lblIgual;
        private System.Windows.Forms.Label lblGalon;
        private System.Windows.Forms.Label lblVolumen;
        private System.Windows.Forms.TextBox txtGalon;
        private System.Windows.Forms.Label lblInstruccion;
    }
}