﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmConvertidorLitroGalon : Form
    {
        public frmConvertidorLitroGalon()
        {
            InitializeComponent();
        }

        private void txtbLitros_TextChanged(object sender, EventArgs e)
        {
            var galon = 0.264172;
            var litro = 0.0;
            var resultado = 0.0;

            try
            {
                litro = Convert.ToDouble(txtbLitros.Text);
                resultado = litro * galon;
                txtGalon.Text = resultado.ToString();
                lblInstruccion.Hide();
            }
            catch (FormatException ex)
            {
                txtbLitros.Clear();
                txtGalon.Clear();
                lblInstruccion.Show();
            }
        }
    }
}
