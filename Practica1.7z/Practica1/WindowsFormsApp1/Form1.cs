﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void comvertorGalónALitroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var isOpen = false;

            foreach (Form f in Application.OpenForms)
            {
                if (f.Name.Equals("frmConvertidorLitroGalon"))
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                var frmConvertor = new frmConvertidorLitroGalon();
                frmConvertor.MdiParent = this;
                frmConvertor.Show();
            }
        }

        private void indiceDeMasaCorporalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var isOpen = false;

            foreach (Form f in Application.OpenForms)
            {
                if (f.Name.Equals("frmIndiceMasaCorporal"))
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                var frmMasaCorporal = new frmIndiceMasaCorporal();
                frmMasaCorporal.MdiParent = this;
                frmMasaCorporal.Show();
            }
        }
    }
}
