﻿namespace WindowsFormsApp1
{
    partial class frmIndiceMasaCorporal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIMC = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblVolumen = new System.Windows.Forms.Label();
            this.lblIgual = new System.Windows.Forms.Label();
            this.lblResultadoIMC = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblClasificacionImc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblIMC
            // 
            this.lblIMC.AutoSize = true;
            this.lblIMC.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIMC.Location = new System.Drawing.Point(12, 90);
            this.lblIMC.Name = "lblIMC";
            this.lblIMC.Size = new System.Drawing.Size(38, 23);
            this.lblIMC.TabIndex = 5;
            this.lblIMC.Text = "IMC";
            this.lblIMC.Visible = false;
            // 
            // txtPeso
            // 
            this.txtPeso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPeso.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtPeso.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeso.Location = new System.Drawing.Point(12, 27);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(167, 32);
            this.txtPeso.TabIndex = 6;
            this.txtPeso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPeso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPeso_KeyPress);
            // 
            // txtAltura
            // 
            this.txtAltura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAltura.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtAltura.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAltura.Location = new System.Drawing.Point(185, 27);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(166, 32);
            this.txtAltura.TabIndex = 7;
            this.txtAltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAltura_KeyPress);
            // 
            // lblAltura
            // 
            this.lblAltura.AutoEllipsis = true;
            this.lblAltura.AutoSize = true;
            this.lblAltura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAltura.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblAltura.Location = new System.Drawing.Point(185, 62);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(166, 15);
            this.lblAltura.TabIndex = 8;
            this.lblAltura.Text = "                                      ALTURA";
            this.lblAltura.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblPeso
            // 
            this.lblPeso.AutoEllipsis = true;
            this.lblPeso.AutoSize = true;
            this.lblPeso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPeso.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblPeso.Location = new System.Drawing.Point(12, 62);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(167, 15);
            this.lblPeso.TabIndex = 9;
            this.lblPeso.Text = "                                           PESO";
            this.lblPeso.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblVolumen
            // 
            this.lblVolumen.AutoSize = true;
            this.lblVolumen.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVolumen.Location = new System.Drawing.Point(12, 9);
            this.lblVolumen.Name = "lblVolumen";
            this.lblVolumen.Size = new System.Drawing.Size(25, 15);
            this.lblVolumen.TabIndex = 10;
            this.lblVolumen.Text = "IMC";
            // 
            // lblIgual
            // 
            this.lblIgual.AutoSize = true;
            this.lblIgual.Font = new System.Drawing.Font("Stencil", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIgual.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblIgual.Location = new System.Drawing.Point(56, 90);
            this.lblIgual.Name = "lblIgual";
            this.lblIgual.Size = new System.Drawing.Size(25, 25);
            this.lblIgual.TabIndex = 11;
            this.lblIgual.Text = "=";
            this.lblIgual.Visible = false;
            // 
            // lblResultadoIMC
            // 
            this.lblResultadoIMC.AutoSize = true;
            this.lblResultadoIMC.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoIMC.Location = new System.Drawing.Point(87, 90);
            this.lblResultadoIMC.Name = "lblResultadoIMC";
            this.lblResultadoIMC.Size = new System.Drawing.Size(106, 23);
            this.lblResultadoIMC.TabIndex = 12;
            this.lblResultadoIMC.Text = "RESULTADO";
            this.lblResultadoIMC.Visible = false;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.Control;
            this.btnCalcular.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(279, 84);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(72, 31);
            this.btnCalcular.TabIndex = 13;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblClasificacionImc
            // 
            this.lblClasificacionImc.AutoSize = true;
            this.lblClasificacionImc.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClasificacionImc.Location = new System.Drawing.Point(12, 124);
            this.lblClasificacionImc.Name = "lblClasificacionImc";
            this.lblClasificacionImc.Size = new System.Drawing.Size(162, 23);
            this.lblClasificacionImc.TabIndex = 12;
            this.lblClasificacionImc.Text = "CLASIFICACIÓN IMC";
            this.lblClasificacionImc.Visible = false;
            // 
            // frmIndiceMasaCorporal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 167);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblClasificacionImc);
            this.Controls.Add(this.lblResultadoIMC);
            this.Controls.Add(this.lblIgual);
            this.Controls.Add(this.lblVolumen);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.lblIMC);
            this.Name = "frmIndiceMasaCorporal";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIMC;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblVolumen;
        private System.Windows.Forms.Label lblIgual;
        private System.Windows.Forms.Label lblResultadoIMC;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblClasificacionImc;
    }
}