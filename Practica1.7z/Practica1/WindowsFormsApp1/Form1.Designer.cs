﻿namespace WindowsFormsApp1
{
    partial class Principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.funcionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comvertorGalónALitroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indiceDeMasaCorporalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calcularNotaParaAprobarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nominaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simulaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funcionesToolStripMenuItem,
            this.nominaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // funcionesToolStripMenuItem
            // 
            this.funcionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comvertorGalónALitroToolStripMenuItem,
            this.indiceDeMasaCorporalToolStripMenuItem,
            this.calcularNotaParaAprobarToolStripMenuItem});
            this.funcionesToolStripMenuItem.Name = "funcionesToolStripMenuItem";
            this.funcionesToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.funcionesToolStripMenuItem.Text = "Funciones";
            // 
            // comvertorGalónALitroToolStripMenuItem
            // 
            this.comvertorGalónALitroToolStripMenuItem.Name = "comvertorGalónALitroToolStripMenuItem";
            this.comvertorGalónALitroToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.comvertorGalónALitroToolStripMenuItem.Text = "Convertidor galón a litro";
            this.comvertorGalónALitroToolStripMenuItem.Click += new System.EventHandler(this.comvertorGalónALitroToolStripMenuItem_Click);
            // 
            // indiceDeMasaCorporalToolStripMenuItem
            // 
            this.indiceDeMasaCorporalToolStripMenuItem.Name = "indiceDeMasaCorporalToolStripMenuItem";
            this.indiceDeMasaCorporalToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.indiceDeMasaCorporalToolStripMenuItem.Text = "Indice de masa corporal";
            this.indiceDeMasaCorporalToolStripMenuItem.Click += new System.EventHandler(this.indiceDeMasaCorporalToolStripMenuItem_Click);
            // 
            // calcularNotaParaAprobarToolStripMenuItem
            // 
            this.calcularNotaParaAprobarToolStripMenuItem.Name = "calcularNotaParaAprobarToolStripMenuItem";
            this.calcularNotaParaAprobarToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.calcularNotaParaAprobarToolStripMenuItem.Text = "Calcular nota para aprobar";
            // 
            // nominaToolStripMenuItem
            // 
            this.nominaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.simulaciónToolStripMenuItem});
            this.nominaToolStripMenuItem.Name = "nominaToolStripMenuItem";
            this.nominaToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.nominaToolStripMenuItem.Text = "Bancario";
            // 
            // simulaciónToolStripMenuItem
            // 
            this.simulaciónToolStripMenuItem.Name = "simulaciónToolStripMenuItem";
            this.simulaciónToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.simulaciónToolStripMenuItem.Text = "Simulación";
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Inicio";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem funcionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comvertorGalónALitroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nominaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indiceDeMasaCorporalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calcularNotaParaAprobarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simulaciónToolStripMenuItem;
    }
}

